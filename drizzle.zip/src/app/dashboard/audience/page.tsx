import Link from "next/link";
import { Users, MailOpen, MousePointerClick, UserMinus, Search, Download, ArrowLeft } from "lucide-react";
import { db } from "../../../db";
import { subscribers } from "../../../db/schema";
import { eq, desc } from "drizzle-orm";
import { auth } from "@clerk/nextjs/server";

type Subscriber = typeof subscribers.$inferSelect;

export default async function AudiencePage() {
  const { userId } = await auth();
  let userSubscribers: Subscriber[] = [];
  
  if (userId) {
    try {
      userSubscribers = await db.select().from(subscribers).where(eq(subscribers.authorId, userId)).orderBy(desc(subscribers.createdAt));
    } catch (e) {
      console.error("DB Fetch Error:", e);
    }
  }

  const activeCount = userSubscribers.filter(s => s.status === 'active' || !s.status).length;
  const unsubsCount = userSubscribers.filter(s => s.status === 'unsubscribed').length;

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      {/* Top Nav */}
      <div className="max-w-[1200px] mx-auto mb-8 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/dashboard" className="p-2 glass border border-border rounded-lg hover:bg-white/5 transition-colors">
            <ArrowLeft className="w-5 h-5 text-gray-400" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Audience</h1>
            <p className="text-sm text-gray-400">Manage subscribers and track engagement</p>
          </div>
        </div>
        <button className="flex items-center gap-2 glass border border-border px-4 py-2 rounded-lg text-sm font-medium hover:bg-white/5 transition-colors">
          <Download className="w-4 h-4" /> Export CSV
        </button>
      </div>

      <main className="max-w-[1200px] mx-auto space-y-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { label: "Total Subscribers", value: userSubscribers.length.toString(), icon: Users, color: "text-primary", trend: "All time" },
            { label: "Active", value: activeCount.toString(), icon: MailOpen, color: "text-purple-400", trend: "Current" },
            { label: "Click Rate", value: "--", icon: MousePointerClick, color: "text-emerald-400", trend: "Coming soon" },
            { label: "Unsubscribed", value: unsubsCount.toString(), icon: UserMinus, color: "text-red-400", trend: "All time" },
          ].map((stat, i) => (
            <div key={i} className="glass border border-border rounded-2xl p-6 relative overflow-hidden group">
              <div className="flex justify-between items-start mb-4">
                <div className={`p-3 rounded-xl bg-surface border border-border ${stat.color}`}>
                  <stat.icon className="w-5 h-5" />
                </div>
              </div>
              <h3 className="text-3xl font-bold mb-1">{stat.value}</h3>
              <p className="text-sm text-gray-400 font-medium mb-2">{stat.label}</p>
              <div className="text-xs text-gray-500 font-mono bg-black/40 border border-border/50 inline-block px-2 py-1 rounded">{stat.trend}</div>
            </div>
          ))}
        </div>

        {/* Subscribers Table */}
        <div className="glass border border-border rounded-2xl overflow-hidden flex flex-col">
          <div className="p-4 border-b border-border flex flex-col sm:flex-row justify-between items-center gap-4 bg-surface/50">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
              <input 
                type="text" 
                placeholder="Search emails..." 
                className="w-full bg-black border border-border rounded-lg pl-9 pr-4 py-2 text-sm focus:outline-none focus:border-primary/50 text-gray-200 placeholder:text-gray-600 transition-colors"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-border bg-black/40 text-xs uppercase tracking-widest text-gray-500 font-semibold">
                  <th className="p-4 font-medium">Subscriber</th>
                  <th className="p-4 font-medium">Status</th>
                  <th className="p-4 font-medium">Date Added</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50 text-sm">
                {userSubscribers.length > 0 ? userSubscribers.map((sub) => (
                  <tr key={sub.id} className="hover:bg-white/[0.02] transition-colors group">
                    <td className="p-4 font-medium text-gray-200">{sub.email}</td>
                    <td className="p-4">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                        sub.status === 'active' || !sub.status ? 'bg-primary/10 text-primary border border-primary/20' :
                        'bg-red-500/10 text-red-500 border border-red-500/20'
                      }`}>
                        {sub.status || 'Active'}
                      </span>
                    </td>
                    <td className="p-4 text-gray-500 font-mono">{sub.createdAt?.toLocaleDateString()}</td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={3} className="p-8 text-center text-gray-500">
                      No subscribers yet. Time to grow your audience!
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}